v1.2.0-beta.1 Pre-release


-log menu is live 

-log Pre-release is live

-log c++ is live